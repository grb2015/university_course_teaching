package ����1;
public class DateFormatException extends IllegalArgumentException{
	public DateFormatException(String message)
	{super(message);
	}
	
	
}
