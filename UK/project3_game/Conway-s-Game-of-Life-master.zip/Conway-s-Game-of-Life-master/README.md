Conway's Game of Life
=====================

Conway's game of life is a cellular automaton devised by the mathematician John Conway. This is a Java, swing based representation of the game.

The executable JAR file can be found in the /dist/ folder of this project.
