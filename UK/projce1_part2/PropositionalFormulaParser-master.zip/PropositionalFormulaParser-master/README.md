# PropositionalFormulaParser

Check whether a zero order forumula is statisfiable, written in C programming language.


Put your formula on input.txt

```
gcc zcabswc.c
```

