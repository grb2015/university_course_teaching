# Tableau Theorem Prover
A tableau theorem prover for propositional logic. Reads a formula, parses it, expands it into a tableau and returns whether it is satisfiable or not.
